# @studymatch/ui

The React component library of **StudyMatch**: 60+ components, 19 achievements with 3D illustrations, and ready-made authentication blocks (login, first-login activation, password recovery, email verification, account management, personality test).

- React 18/19 · TypeScript types included · ES module
- One stylesheet, every class prefixed with `sm-`, every token with `--sm-`
- Accessible: focus rings, keyboard support, ARIA roles, reduced motion
- Backend-agnostic auth: a mock adapter for prototypes, an HTTP adapter for real APIs

## Install

```bash
npm install ./studymatch-ui-1.0.0.tgz
```

## Use

```tsx
import '@studymatch/ui/styles.css';
import { StudyMatchProvider, Button, useToast } from '@studymatch/ui';

function Publish() {
  const toast = useToast();
  return <Button onClick={() => toast.success('Groups published')}>Publish groups</Button>;
}

export default function App() {
  return (
    <StudyMatchProvider>
      <Publish />
    </StudyMatchProvider>
  );
}
```

## Authentication

```tsx
import { AuthProvider, AuthLayout, LoginForm, createMockAuthAdapter } from '@studymatch/ui';

const adapter = createMockAuthAdapter(); // or createHttpAuthAdapter({ baseUrl: '/api' })

<AuthProvider adapter={adapter}>
  <AuthLayout>
    <LoginForm onAuthenticated={(session, step) => navigate(step === 'home' ? '/' : `/${step}`)} />
  </AuthLayout>
</AuthProvider>
```

## Theming

Override any token:

```css
:root {
  --sm-violet: #0f766e;
  --sm-font: 'Inter', system-ui, sans-serif;
}
```

Full documentation, live examples and the source of every component are in the StudyMatch UI docs site (`npm run dev` in the monorepo).
